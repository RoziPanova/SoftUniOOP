﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public abstract class BaseEntity
    {
        public string ID { get; set; }
    }
}
